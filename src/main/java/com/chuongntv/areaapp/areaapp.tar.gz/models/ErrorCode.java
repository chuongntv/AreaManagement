package com.chuongntv.areaapp.models;

/**
 * Created by chuongntv on 12/18/15.
 */
public class ErrorCode {
    public static final int ERROR = 0;
    public static final int SUCCESS = 1;
}
