package com.chuongntv.areaapp.controllers;

import com.chuongntv.areaapp.models.Country;
import com.chuongntv.areaapp.models.ErrorCode;
import com.chuongntv.areaapp.models.ErrorMessage;
import com.chuongntv.areaapp.repositories.CountryRepository;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import java.util.List;

/**
 * Created by chuongntv on 12/17/15.
 */
@Controller
@RequestMapping("/country")
public class CountryController {
    @Autowired
    private CountryRepository countryRepository;
    private final String URL = "http://localhost:8080/api/country";
    private Gson gson = new Gson();
    @RequestMapping("/list/{id}")
    public String list(Model model, @PathVariable String id){
        RestTemplate restTemplate = new RestTemplate();
        String strJson,result;
        try {
            ResponseEntity<String> responseEntity = restTemplate.exchange(URL + "/fetch/page/" + id, HttpMethod.GET,null,String.class);
            strJson = responseEntity.getBody();
            if(responseEntity.getStatusCode()== HttpStatus.OK){

                ErrorMessage errorMessage = gson.fromJson(strJson,ErrorMessage.class);
                if(errorMessage.getErrorCode()==ErrorCode.SUCCESS){
                    TypeToken<List<Country>> token = new TypeToken<List<Country>>() {};
                    List<Country> lstCountries = gson.fromJson(errorMessage.getContent(),token.getType());
                    model.addAttribute("errorMessage","SUCCESS");
                    model.addAttribute("lstCountries",lstCountries);

                }else{
                    model.addAttribute("errorMessage",errorMessage.getContent());
                }
            }
        }catch (Exception ex){
            //strJson = responseEntity.getBody();
            System.out.println(ex.getMessage());
        }
        return "country/list";
    }
}
