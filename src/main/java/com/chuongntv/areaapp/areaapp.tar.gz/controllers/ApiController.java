package com.chuongntv.areaapp.controllers;

import com.chuongntv.areaapp.models.*;
import com.chuongntv.areaapp.repositories.CityRepository;
import com.chuongntv.areaapp.repositories.CountryRepository;
import com.chuongntv.areaapp.repositories.DistrictRepository;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by chuongntv on 12/17/15.
 */
@RestController
@RequestMapping("/api")
public class ApiController {

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private CityRepository cityRepository;

    @Autowired
    private DistrictRepository districtRepository;

    private final int NumberOfItemPerPage = 10;

    private Gson gson = new Gson();

    // API for Country
    @RequestMapping("/country/fetch")
    public ResponseEntity<?> fetchAllCountry() {
        List<Country> lstCountries = (List<Country>) countryRepository.findAll();
        return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS, gson.toJson(lstCountries)), HttpStatus.OK);
    }

    @RequestMapping("/country/fetch/{strId}")
    public ResponseEntity<?> fetchCountryById(@PathVariable String strId) {
        try {
            Integer id = Integer.parseInt(strId);
            Country country = countryRepository.findOne(id);
            if (country == null)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Invalid Country"), HttpStatus.OK);
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS, gson.toJson(country)), HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
    }

    @RequestMapping("/country/fetch/page/{strPageNumber}")
    public ResponseEntity<?> fetchCountryByPage(@PathVariable String strPageNumber) {
        try {
            if (strPageNumber == null || strPageNumber.isEmpty())
                strPageNumber = "0";
            Integer pageNumber = Integer.parseInt(strPageNumber);
            List<Country> lstCountries = (List<Country>) countryRepository.findAll();
            Integer indexBegin = Math.min((pageNumber - 1) * NumberOfItemPerPage, lstCountries.size());
            Integer indexEnd = Math.min(indexBegin + NumberOfItemPerPage, lstCountries.size());
            if (pageNumber > 0)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS, gson.toJson(lstCountries.subList(indexBegin, indexEnd))), HttpStatus.OK);
            else
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Invalid Page Number"), HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/country/save", method = RequestMethod.POST)
    public ResponseEntity<?> saveCountry(@RequestBody Country country) {
        try {
            if (country.getName() == null || country.getName().isEmpty())
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Country Name is not Empty"), HttpStatus.OK);
            if (country.getCode() == null || country.getCode().isEmpty())
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Country Code is not Empty"), HttpStatus.OK);
            Country ct = countryRepository.findOne(country.getId());
            if (ct != null) {
                if (countryRepository.findByCode(ct.getCode()).size() > 1)
                    return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Country Code is not available"), HttpStatus.OK);
            } else {
                if (countryRepository.findByCode(ct.getCode()).size() > 0)
                    return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Country Code is not available"), HttpStatus.OK);
            }
            countryRepository.save(ct);
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS, gson.toJson(ct)), HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/country/delete/{strId}", method = RequestMethod.POST)
    public ResponseEntity<?> deleteCountry(@PathVariable String strId) {
        try {
            Integer id = Integer.parseInt(strId);
            Country ct = countryRepository.findOne(id);
            if (ct == null)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Country is not available"), HttpStatus.OK);
            countryRepository.delete(ct);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS,"Delete Success"), HttpStatus.OK);
    }

    // API for City
    @RequestMapping("/city/fetch")
    public ResponseEntity<?> fectchAllCity() {
        List<City> lstCities = (List<City>) cityRepository.findAll();
        return new ResponseEntity<>(lstCities, HttpStatus.OK);
    }

    @RequestMapping("/city/fetch/{strId}")
    public ResponseEntity<?> fetchCityById(@PathVariable String strId) {
        try {
            Integer id = Integer.parseInt(strId);
            City city = cityRepository.findOne(id);
            if (city == null)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Invalid City"), HttpStatus.OK);
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS,gson.toJson(city)), HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
    }

    @RequestMapping("/city/fetch/page/{strPageNumber}")
    public ResponseEntity<?> fetchCityByPage(@PathVariable String strPageNumber) {
        try {
            if (strPageNumber == null || strPageNumber.isEmpty())
                strPageNumber = "0";
            Integer pageNumber = Integer.parseInt(strPageNumber);
            List<City> lstCities = (List<City>) cityRepository.findAll();
            Integer indexBegin = Math.min((pageNumber - 1) * NumberOfItemPerPage, lstCities.size());
            Integer indexEnd = Math.min(indexBegin + NumberOfItemPerPage, lstCities.size());
            if (pageNumber > 0)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS,gson.toJson(lstCities.subList(indexBegin, indexEnd))), HttpStatus.OK);
            else
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Invalid Page Number"), HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/city/save", method = RequestMethod.POST)
    public ResponseEntity<?> saveCity(@RequestBody City city) {
        try {
            if (city.getName() == null || city.getName().isEmpty())
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"City Name is not Empty"), HttpStatus.OK);
            if (city.getCode() == null || city.getCode().isEmpty())
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"City Code is not Empty"), HttpStatus.OK);
            if (city.getCountry() == null)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Country is not Empty"), HttpStatus.OK);

            City ct = cityRepository.findOne(city.getId());
            if (ct != null) {
                if (cityRepository.findByCode(ct.getCode()).size() > 1)
                    return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"City Code is not available"), HttpStatus.OK);
                if (countryRepository.findOne(ct.getCountry().getId()) == null)
                    return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Country is not available"), HttpStatus.OK);
            } else {
                if (cityRepository.findByCode(ct.getCode()).size() > 0)
                    return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"City Code is not available"), HttpStatus.OK);
            }
            cityRepository.save(ct);
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS,gson.toJson(ct)), HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/city/delete/{strId}", method = RequestMethod.POST)
    public ResponseEntity<?> deleteCity(@PathVariable String strId) {
        try {
            Integer id = Integer.parseInt(strId);
            City ct = cityRepository.findOne(id);
            if (ct == null)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"City is not available"), HttpStatus.OK);
            cityRepository.delete(ct);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS,"Delete Success"), HttpStatus.OK);
    }

    // API for District
    @RequestMapping("/district/fetch")
    public ResponseEntity<?> fetchAllDistrict() {
        List<District> lstDistricts = (List<District>) districtRepository.findAll();
        return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS,gson.toJson(lstDistricts)), HttpStatus.OK);
    }

    @RequestMapping("/district/fetch/{strId}")
    public ResponseEntity<?> fetchDistrictById(@PathVariable String strId) {
        try {
            Integer id = Integer.parseInt(strId);
            District district = districtRepository.findOne(id);
            if (district == null)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Invalid District"), HttpStatus.OK);
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS,gson.toJson(district)), HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
    }

    @RequestMapping("/district/fetch/page/{strPageNumber}")
    public ResponseEntity<?> fetchDistrictByPage(@PathVariable String strPageNumber) {
        try {
            if (strPageNumber == null || strPageNumber.isEmpty())
                strPageNumber = "0";
            Integer pageNumber = Integer.parseInt(strPageNumber);
            List<District> lstDistricts = (List<District>) districtRepository.findAll();
            Integer indexBegin = Math.min((pageNumber - 1) * NumberOfItemPerPage, lstDistricts.size());
            Integer indexEnd = Math.min(indexBegin + NumberOfItemPerPage, lstDistricts.size());
            if (pageNumber > 0)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS,gson.toJson(lstDistricts.subList(indexBegin, indexEnd))), HttpStatus.OK);
            else
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"Invalid Page Number"), HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/district/save", method = RequestMethod.POST)
    public ResponseEntity<?> saveDistrict(@RequestBody District district) {
        try {
            if (district.getName() == null || district.getName().isEmpty())
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"District Name is not Empty"), HttpStatus.OK);
            if (district.getCode() == null || district.getCode().isEmpty())
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"District Code is not Empty"), HttpStatus.OK);
            if (district.getCity() == null)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"City Code is not Empty"), HttpStatus.OK);
            District dt = districtRepository.findOne(district.getId());
            if (dt != null) {
                if (districtRepository.findByCode(dt.getCode()).size() > 1)
                    return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"District Code is not available"), HttpStatus.OK);
                if (cityRepository.findByCode(dt.getCity().getCode())==null)
                    return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"City is not available"), HttpStatus.OK);
            } else {
                if (districtRepository.findByCode(dt.getCode()).size() > 0)
                    return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"District Code is not available"), HttpStatus.OK);
            }
            districtRepository.save(dt);
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS,gson.toJson(dt)), HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/district/delete/{strId}", method = RequestMethod.POST)
    public ResponseEntity<?> deleteDistrict(@PathVariable String strId) {
        try {
            Integer id = Integer.parseInt(strId);
            District dt = districtRepository.findOne(id);
            if (dt == null)
                return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,"City is not available"), HttpStatus.OK);
            districtRepository.delete(dt);
        } catch (Exception ex) {
            return new ResponseEntity<>(new ErrorMessage(ErrorCode.ERROR,ex.getMessage()), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ErrorMessage(ErrorCode.SUCCESS,"Delete Success"), HttpStatus.OK);
    }
}
